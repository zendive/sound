----------------------
Copyright Information:
----------------------
TabletSynth is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

The GNU General Public License can be found at
<http://www.gnu.org/licenses/>.

----------------------
TabletSynth
----------------------
Author: Jakob Rogstadius <jakob.rogstadius@gmail.com>

----------------------
Software Requirements:
----------------------
Microsoft .NET Framework 3.5
https://www.microsoft.com/downloads/details.aspx?FamilyId=333325FD-AE52-4E35-B531-508D977D32A6&displaylang=en

Parallel Extensions to .NET Framework 3.5 June 2008 CTP
http://www.microsoft.com/downloads/details.aspx?FamilyId=348F73FD-593D-4B3C-B055-694C50D2B0F3&displaylang=en

----------------------
Hardware Requirements:
----------------------
A graphics tablet with a pen that preferably supports pressure, 2D positioning
and two pen angles. The software has been tested with a Wacom Intuos 2, a Grip 
Pen and a 4D Mouse.

An Intel Core 2 Duo 2.5 GHz CPU or higher. A quad core CPU is recommended.
