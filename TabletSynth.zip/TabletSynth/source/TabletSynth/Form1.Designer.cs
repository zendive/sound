﻿namespace TabletSynth
{
    partial class TabletSynth
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TabletSynth));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.labelTabletData = new System.Windows.Forms.Label();
            this.textBoxSinusoidCount = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.panelGraph = new System.Windows.Forms.Panel();
            this.radioButtonDiscrete = new System.Windows.Forms.RadioButton();
            this.radioButtonContinuous = new System.Windows.Forms.RadioButton();
            this.textBoxMinFq = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.textBoxNoteCount = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBoxFunction2 = new System.Windows.Forms.TextBox();
            this.textBoxFunction1 = new System.Windows.Forms.TextBox();
            this.labelCompileError1 = new System.Windows.Forms.Label();
            this.labelCompileError2 = new System.Windows.Forms.Label();
            this.textBoxW0Code = new System.Windows.Forms.TextBox();
            this.textBoxAmplitudeCode = new System.Windows.Forms.TextBox();
            this.textBoxWidthCode = new System.Windows.Forms.TextBox();
            this.textBoxCenterCode = new System.Windows.Forms.TextBox();
            this.textBoxSharpnessCode = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBoxExponentCode = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.textBoxPen1 = new System.Windows.Forms.TextBox();
            this.textBoxPen2 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 198);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "w0 =";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(618, 65);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Sinusoids";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 247);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "amplitude =";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(9, 296);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "width =";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 345);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "center =";
            // 
            // labelTabletData
            // 
            this.labelTabletData.AutoSize = true;
            this.labelTabletData.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTabletData.Location = new System.Drawing.Point(618, 195);
            this.labelTabletData.Name = "labelTabletData";
            this.labelTabletData.Size = new System.Drawing.Size(43, 13);
            this.labelTabletData.TabIndex = 5;
            this.labelTabletData.Text = "label6";
            // 
            // textBoxSinusoidCount
            // 
            this.textBoxSinusoidCount.Location = new System.Drawing.Point(676, 62);
            this.textBoxSinusoidCount.Name = "textBoxSinusoidCount";
            this.textBoxSinusoidCount.Size = new System.Drawing.Size(47, 20);
            this.textBoxSinusoidCount.TabIndex = 2;
            this.textBoxSinusoidCount.Text = "200";
            this.textBoxSinusoidCount.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 179);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(544, 13);
            this.label6.TabIndex = 4;
            this.label6.Text = "Input variables: pressure1, x1, y1, s1, t1, pressure2, x2, y2, s2, t2, sinusoidCo" +
                "unt, noteCount, minFq, discreteNotes";
            // 
            // panelGraph
            // 
            this.panelGraph.Location = new System.Drawing.Point(12, 12);
            this.panelGraph.Name = "panelGraph";
            this.panelGraph.Size = new System.Drawing.Size(600, 160);
            this.panelGraph.TabIndex = 7;
            // 
            // radioButtonDiscrete
            // 
            this.radioButtonDiscrete.AutoSize = true;
            this.radioButtonDiscrete.Location = new System.Drawing.Point(621, 140);
            this.radioButtonDiscrete.Name = "radioButtonDiscrete";
            this.radioButtonDiscrete.Size = new System.Drawing.Size(64, 17);
            this.radioButtonDiscrete.TabIndex = 5;
            this.radioButtonDiscrete.Text = "Discrete";
            this.radioButtonDiscrete.UseVisualStyleBackColor = true;
            // 
            // radioButtonContinuous
            // 
            this.radioButtonContinuous.AutoSize = true;
            this.radioButtonContinuous.Checked = true;
            this.radioButtonContinuous.Location = new System.Drawing.Point(621, 163);
            this.radioButtonContinuous.Name = "radioButtonContinuous";
            this.radioButtonContinuous.Size = new System.Drawing.Size(78, 17);
            this.radioButtonContinuous.TabIndex = 6;
            this.radioButtonContinuous.TabStop = true;
            this.radioButtonContinuous.Text = "Continuous";
            this.radioButtonContinuous.UseVisualStyleBackColor = true;
            // 
            // textBoxMinFq
            // 
            this.textBoxMinFq.Location = new System.Drawing.Point(676, 88);
            this.textBoxMinFq.Name = "textBoxMinFq";
            this.textBoxMinFq.Size = new System.Drawing.Size(47, 20);
            this.textBoxMinFq.TabIndex = 3;
            this.textBoxMinFq.Text = "13,75";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(618, 91);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(39, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "Min fq:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(618, 117);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(38, 13);
            this.label9.TabIndex = 4;
            this.label9.Text = "Notes:";
            // 
            // textBoxNoteCount
            // 
            this.textBoxNoteCount.Location = new System.Drawing.Point(676, 114);
            this.textBoxNoteCount.Name = "textBoxNoteCount";
            this.textBoxNoteCount.Size = new System.Drawing.Size(47, 20);
            this.textBoxNoteCount.TabIndex = 4;
            this.textBoxNoteCount.Text = "100";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(729, 91);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(20, 13);
            this.label10.TabIndex = 4;
            this.label10.Text = "Hz";
            // 
            // textBoxFunction2
            // 
            this.textBoxFunction2.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxFunction2.Location = new System.Drawing.Point(75, 603);
            this.textBoxFunction2.Multiline = true;
            this.textBoxFunction2.Name = "textBoxFunction2";
            this.textBoxFunction2.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxFunction2.Size = new System.Drawing.Size(535, 77);
            this.textBoxFunction2.TabIndex = 14;
            this.textBoxFunction2.Text = resources.GetString("textBoxFunction2.Text");
            this.textBoxFunction2.TextChanged += new System.EventHandler(this.textBoxFunction2_TextChanged);
            // 
            // textBoxFunction1
            // 
            this.textBoxFunction1.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxFunction1.Location = new System.Drawing.Point(75, 525);
            this.textBoxFunction1.Multiline = true;
            this.textBoxFunction1.Name = "textBoxFunction1";
            this.textBoxFunction1.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxFunction1.Size = new System.Drawing.Size(535, 77);
            this.textBoxFunction1.TabIndex = 13;
            this.textBoxFunction1.Text = "return 1 / (sharpness - (sharpness - 1) * Math.Cos(frequency / w0));";
            this.textBoxFunction1.TextChanged += new System.EventHandler(this.textBoxFunction1_TextChanged);
            // 
            // labelCompileError1
            // 
            this.labelCompileError1.AutoSize = true;
            this.labelCompileError1.Location = new System.Drawing.Point(577, 509);
            this.labelCompileError1.Name = "labelCompileError1";
            this.labelCompileError1.Size = new System.Drawing.Size(0, 13);
            this.labelCompileError1.TabIndex = 12;
            // 
            // labelCompileError2
            // 
            this.labelCompileError2.AutoSize = true;
            this.labelCompileError2.Location = new System.Drawing.Point(577, 629);
            this.labelCompileError2.Name = "labelCompileError2";
            this.labelCompileError2.Size = new System.Drawing.Size(0, 13);
            this.labelCompileError2.TabIndex = 12;
            // 
            // textBoxW0Code
            // 
            this.textBoxW0Code.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxW0Code.Location = new System.Drawing.Point(76, 195);
            this.textBoxW0Code.Multiline = true;
            this.textBoxW0Code.Name = "textBoxW0Code";
            this.textBoxW0Code.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxW0Code.Size = new System.Drawing.Size(534, 48);
            this.textBoxW0Code.TabIndex = 7;
            this.textBoxW0Code.Text = resources.GetString("textBoxW0Code.Text");
            this.textBoxW0Code.TextChanged += new System.EventHandler(this.textBoxW0Code_TextChanged);
            // 
            // textBoxAmplitudeCode
            // 
            this.textBoxAmplitudeCode.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxAmplitudeCode.Location = new System.Drawing.Point(76, 244);
            this.textBoxAmplitudeCode.Multiline = true;
            this.textBoxAmplitudeCode.Name = "textBoxAmplitudeCode";
            this.textBoxAmplitudeCode.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxAmplitudeCode.Size = new System.Drawing.Size(535, 48);
            this.textBoxAmplitudeCode.TabIndex = 8;
            this.textBoxAmplitudeCode.Text = "double p = pressure1 / 1024.0;\r\nreturn p*p*p;";
            this.textBoxAmplitudeCode.TextChanged += new System.EventHandler(this.textBoxAmplitudeCode_TextChanged);
            // 
            // textBoxWidthCode
            // 
            this.textBoxWidthCode.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxWidthCode.Location = new System.Drawing.Point(76, 293);
            this.textBoxWidthCode.Multiline = true;
            this.textBoxWidthCode.Name = "textBoxWidthCode";
            this.textBoxWidthCode.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxWidthCode.Size = new System.Drawing.Size(535, 48);
            this.textBoxWidthCode.TabIndex = 9;
            this.textBoxWidthCode.Text = "return 50.05 + t1 * 50;";
            this.textBoxWidthCode.TextChanged += new System.EventHandler(this.textBoxWidthCode_TextChanged);
            // 
            // textBoxCenterCode
            // 
            this.textBoxCenterCode.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxCenterCode.Location = new System.Drawing.Point(76, 342);
            this.textBoxCenterCode.Multiline = true;
            this.textBoxCenterCode.Name = "textBoxCenterCode";
            this.textBoxCenterCode.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxCenterCode.Size = new System.Drawing.Size(535, 48);
            this.textBoxCenterCode.TabIndex = 10;
            this.textBoxCenterCode.Text = "return 2 + 2 * Math.Pow(s1 + 1, 3) - 1;";
            this.textBoxCenterCode.TextChanged += new System.EventHandler(this.textBoxCenterCode_TextChanged);
            // 
            // textBoxSharpnessCode
            // 
            this.textBoxSharpnessCode.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxSharpnessCode.Location = new System.Drawing.Point(76, 391);
            this.textBoxSharpnessCode.Multiline = true;
            this.textBoxSharpnessCode.Name = "textBoxSharpnessCode";
            this.textBoxSharpnessCode.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxSharpnessCode.Size = new System.Drawing.Size(535, 48);
            this.textBoxSharpnessCode.TabIndex = 11;
            this.textBoxSharpnessCode.Text = "return Math.Pow(1000.0, Math.Pow(1000 * (1 - y1) + 0.01, 1.1) / 2000.0);";
            this.textBoxSharpnessCode.TextChanged += new System.EventHandler(this.textBoxSharpnessCode_TextChanged);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(9, 394);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(64, 13);
            this.label11.TabIndex = 4;
            this.label11.Text = "sharpness =";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(8, 528);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(62, 13);
            this.label12.TabIndex = 4;
            this.label12.Text = "Amplitude 1";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(8, 606);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(62, 13);
            this.label13.TabIndex = 4;
            this.label13.Text = "Amplitude 2";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(9, 443);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(60, 13);
            this.label14.TabIndex = 4;
            this.label14.Text = "exponent =";
            // 
            // textBoxExponentCode
            // 
            this.textBoxExponentCode.Font = new System.Drawing.Font("Courier New", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxExponentCode.Location = new System.Drawing.Point(76, 440);
            this.textBoxExponentCode.Multiline = true;
            this.textBoxExponentCode.Name = "textBoxExponentCode";
            this.textBoxExponentCode.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxExponentCode.Size = new System.Drawing.Size(535, 48);
            this.textBoxExponentCode.TabIndex = 12;
            this.textBoxExponentCode.Text = "return (1 - y2) * 10.0 + 0.05;";
            this.textBoxExponentCode.TextChanged += new System.EventHandler(this.textBoxExponentCode_TextChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(618, 13);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(52, 13);
            this.label15.TabIndex = 4;
            this.label15.Text = "Pen 1 ID:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(618, 39);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(52, 13);
            this.label16.TabIndex = 4;
            this.label16.Text = "Pen 2 ID:";
            // 
            // textBoxPen1
            // 
            this.textBoxPen1.Location = new System.Drawing.Point(676, 10);
            this.textBoxPen1.Name = "textBoxPen1";
            this.textBoxPen1.Size = new System.Drawing.Size(47, 20);
            this.textBoxPen1.TabIndex = 0;
            this.textBoxPen1.Text = "1";
            // 
            // textBoxPen2
            // 
            this.textBoxPen2.Location = new System.Drawing.Point(676, 36);
            this.textBoxPen2.Name = "textBoxPen2";
            this.textBoxPen2.Size = new System.Drawing.Size(47, 20);
            this.textBoxPen2.TabIndex = 1;
            this.textBoxPen2.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(618, 405);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(43, 13);
            this.label7.TabIndex = 5;
            this.label7.Text = "label6";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(8, 509);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(318, 13);
            this.label17.TabIndex = 4;
            this.label17.Text = "Input variables: w0, amplitude, width, center, sharpness, exponent";
            // 
            // TabletSynth
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(754, 689);
            this.Controls.Add(this.textBoxExponentCode);
            this.Controls.Add(this.textBoxSharpnessCode);
            this.Controls.Add(this.textBoxCenterCode);
            this.Controls.Add(this.textBoxWidthCode);
            this.Controls.Add(this.textBoxAmplitudeCode);
            this.Controls.Add(this.textBoxW0Code);
            this.Controls.Add(this.labelCompileError2);
            this.Controls.Add(this.labelCompileError1);
            this.Controls.Add(this.textBoxFunction1);
            this.Controls.Add(this.textBoxFunction2);
            this.Controls.Add(this.textBoxPen2);
            this.Controls.Add(this.textBoxNoteCount);
            this.Controls.Add(this.textBoxPen1);
            this.Controls.Add(this.textBoxMinFq);
            this.Controls.Add(this.radioButtonContinuous);
            this.Controls.Add(this.radioButtonDiscrete);
            this.Controls.Add(this.panelGraph);
            this.Controls.Add(this.textBoxSinusoidCount);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.labelTabletData);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "TabletSynth";
            this.Text = "TabletSynth";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelTabletData;
        private System.Windows.Forms.TextBox textBoxSinusoidCount;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panelGraph;
        private System.Windows.Forms.RadioButton radioButtonDiscrete;
        private System.Windows.Forms.RadioButton radioButtonContinuous;
        private System.Windows.Forms.TextBox textBoxMinFq;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBoxNoteCount;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBoxFunction2;
        private System.Windows.Forms.TextBox textBoxFunction1;
        private System.Windows.Forms.Label labelCompileError1;
        private System.Windows.Forms.Label labelCompileError2;
        private System.Windows.Forms.TextBox textBoxW0Code;
        private System.Windows.Forms.TextBox textBoxAmplitudeCode;
        private System.Windows.Forms.TextBox textBoxWidthCode;
        private System.Windows.Forms.TextBox textBoxCenterCode;
        private System.Windows.Forms.TextBox textBoxSharpnessCode;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBoxExponentCode;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBoxPen1;
        private System.Windows.Forms.TextBox textBoxPen2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label17;
    }
}

