﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace TabletSynth
{
    class SinusSource
    {
        double _fq;
        int _sr;
        double _phase = 0;
        const double TWO_PI = 2 * Math.PI;
        short[] _samples = new short[0];

        public SinusSource(double frequency, int sampleRate)
        {
            _fq = frequency;
            _sr = sampleRate;
        }

        public void GetSamples(IntPtr dataPtr, int sampleCount)
        {
            _fq++;

            long before = HiResTimer.Ticks;

            double phaseIncrement = _fq * TWO_PI / _sr;

            int s = sampleCount / 2;
            if (_samples.Length < s)
                _samples = new short[s];

            //for (int i = 0; i < s; i++)
            //{
            //    _phase = (_phase + phaseIncrement) % TWO_PI;
            //    _samples[i] = (short)(short.MaxValue * Math.Sin(_phase));
            //}

            Parallel.For(0, s, i =>
            {
                double phase = _phase + phaseIncrement * i;
                short value = (short)(short.MaxValue * Math.Sin(phase));
                _samples[i] = value;
            });

            _phase = (_phase + s * phaseIncrement) % TWO_PI;

            Console.WriteLine(1000 * (HiResTimer.Ticks - before) / (double)HiResTimer.TicksPerSecond);

            System.Runtime.InteropServices.Marshal.Copy(_samples, 0, dataPtr, s);
        }
    }
}
