//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
//  KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
//  IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR
//  PURPOSE.
//
//  This material may not be duplicated in whole or in part, except for 
//  personal use, without the express written consent of the author. 
//
//  web:    http://www.chronotron.com 
//  email:  ianier@hotmail.com
//
//  Copyright (C) 1999-2003 Ianier Munoz. All Rights Reserved.

using System;
using System.IO;
using System.Windows.Forms;
using Microsoft.DirectX.DirectSound;
using System.Runtime.InteropServices;
using System.Threading;

namespace TabletSynth
{
	/// <summary>
	/// An audio streaming player using DirectSound
	/// </summary>
	public class StreamingPlayer : IDisposable, IAudioPlayer
	{
		private const int _maxLatencyMs = 100;

        private Device _device;
        private bool _ownsDevice;
        private SecondaryBuffer _secondaryBuffer;
        private System.Timers.Timer _updateTimer;
        private int _nextWritePos;
        private int _bufferByteCount;
        private Stream _pullStream;
       
		private class PullStream : Stream 
		{
			private PullAudioCallback m_PullAudio;

			public PullStream(PullAudioCallback pullAudio)
			{
				m_PullAudio = pullAudio;
			}

			public override bool CanRead { get { return true; } }
			public override bool CanSeek { get { return false; } }
			public override bool CanWrite { get { return false; } }
			public override long Length { get { return 0; } }
			public override long Position { get { return 0; } set {} }
			public override void Close() {}
			public override void Flush() {}
			public override int Read(byte[] buffer, int offset, int count)
			{
				if (m_PullAudio != null)
				{
					GCHandle h = GCHandle.Alloc(buffer, GCHandleType.Pinned);
					try
					{
						m_PullAudio(new IntPtr(h.AddrOfPinnedObject().ToInt64() + offset), count);
					}
					finally
					{
						h.Free();
					}
				}
				else
				{
					for (int i = offset; i < offset + count; i++)
						buffer[i] = 0;
				}
				return count;
			}
			public override long Seek(long offset, System.IO.SeekOrigin origin) { return 0; }
			public override void SetLength(long length) {}
			public override void Write(byte[] buffer, int offset, int count) {}
			public override void WriteByte(byte value) {}
		}

		/// <summary>
		/// Helper function for creating WaveFormat instances
		/// </summary>
		/// <param name="sr">Sampling rate</param>
		/// <param name="bps">Bits per sample</param>
		/// <param name="ch">Channels</param>
		/// <returns></returns>
		public static WaveFormat CreateWaveFormat(int sr, short bps, short ch)
		{
			WaveFormat wfx = new WaveFormat();

			wfx.FormatTag = WaveFormatTag.Pcm;
			wfx.SamplesPerSecond = sr;
			wfx.BitsPerSample = bps;
			wfx.Channels = ch;

			wfx.BlockAlign = (short)(wfx.Channels * (wfx.BitsPerSample / 8));
			wfx.AverageBytesPerSecond = wfx.SamplesPerSecond * wfx.BlockAlign;

			return wfx;
		}

		public StreamingPlayer(Control owner, int sr, short bps, short ch) : 
			this(owner, null, CreateWaveFormat(sr, bps, ch))
		{
		}

		public StreamingPlayer(Control owner, WaveFormat format) : 
			this(owner, null, format)
		{
		}

		public StreamingPlayer(Control owner, Device device, int sr, short bps, short ch) : 
			this(owner, device, CreateWaveFormat(sr, bps, ch))
		{
		}

		public StreamingPlayer(Control owner, Device device, WaveFormat format)
		{
			_device = device;
			if (_device == null)
			{
				_device = new Device();
				_device.SetCooperativeLevel(owner, CooperativeLevel.Normal);
				_ownsDevice = true;
			}

			BufferDescription desc = new BufferDescription(format);
			desc.BufferBytes = format.AverageBytesPerSecond;
			desc.ControlVolume = true;
			desc.GlobalFocus = true;

			_secondaryBuffer = new SecondaryBuffer(desc, _device);
			_bufferByteCount = _secondaryBuffer.Caps.BufferBytes;

			//m_Timer = new System.Timers.Timer(BytesToMs(m_BufferBytes) / 90);
            _updateTimer = new System.Timers.Timer(_maxLatencyMs * 0.2);
			_updateTimer.Enabled = false;
			_updateTimer.Elapsed += new System.Timers.ElapsedEventHandler(Timer_Elapsed);
		}

		~StreamingPlayer()
		{
			Dispose();
		}

		public void Dispose()
		{
			Stop();
			if (_updateTimer != null)
			{
				_updateTimer.Dispose();
				_updateTimer = null;
			}
			if (_secondaryBuffer != null)
			{
				_secondaryBuffer.Dispose();
				_secondaryBuffer = null;
			}
			if (_ownsDevice && _device != null)
			{
				_device.Dispose();
				_device = null;
			}
			GC.SuppressFinalize(this);
		}

		// IAudioPlayer

		public int SamplingRate { get { return _secondaryBuffer.Format.SamplesPerSecond; }  }
		public int BitsPerSample { get { return _secondaryBuffer.Format.BitsPerSample; } }
		public int Channels { get { return _secondaryBuffer.Format.Channels; } }

		public void Play(PullAudioCallback pullAudio)
		{
            if (_run)
                return;

			Stop();

			_pullStream = new PullStream(pullAudio);

			_secondaryBuffer.SetCurrentPosition(0);
			_nextWritePos = 0;
			Feed(MsToBytes(_maxLatencyMs));
			//_updateTimer.Enabled = true;
            _run = true;
            Thread t = new Thread(SoundLoop);
            t.Start();
			_secondaryBuffer.Play(0, BufferPlayFlags.Looping);
		}

		public void Stop()
		{
            _run = false;

            //if (_updateTimer != null)
            //    _updateTimer.Enabled = false;
			if (_secondaryBuffer != null && !_secondaryBuffer.Disposed)
				_secondaryBuffer.Stop();
		}

        bool _run;
        public void SoundLoop()
        {
            while (_run)
            {
                Timer_Elapsed(null, null);
                Thread.Sleep(10);
            }
        }

		public int GetBufferedSize()
		{
            throw new NotImplementedException();

            //int played = GetPlayedSize();
            //return played > 0 && played < _bufferByteCount ? _bufferByteCount - played : 0;
		}

        public Device Device
		{
			get { return _device; }
		}

		private int BytesToMs(int bytes)
		{
			return bytes * 1000 / _secondaryBuffer.Format.AverageBytesPerSecond;
		}

		private int MsToBytes(int ms)
		{
			int bytes = ms * _secondaryBuffer.Format.AverageBytesPerSecond / 1000;
			bytes -= bytes % _secondaryBuffer.Format.BlockAlign;
			return bytes;
		}

		private void Feed(int tocopy)
		{
			// limit latency to some milliseconds
            //int tocopy = Math.Min(bytes, MsToBytes(_maxLatencyMs));

            if (tocopy <= 0)
                return;

            // restore buffer
			if (_secondaryBuffer.Status.BufferLost)
				_secondaryBuffer.Restore();

			// copy data to the buffer
            //if (m_NextWrite + tocopy < m_Buffer.Format.AverageBytesPerSecond)
            //{
                _secondaryBuffer.Write(_nextWritePos, _pullStream, tocopy, LockFlag.None);
            //}
            //else
            //{
            //    int partOne = m_Buffer.Format.AverageBytesPerSecond - m_NextWrite;
            //    int partTwo = tocopy - partOne;
            //    m_Buffer.Write(m_NextWrite, m_PullStream, partOne, LockFlag.None);
            //    m_Buffer.Write(0, m_PullStream, partTwo, LockFlag.None);
            //}

			_nextWritePos += tocopy;
            if (_nextWritePos >= _bufferByteCount)
            {
                _nextWritePos -= _bufferByteCount;
            }
		}

        //private int GetPlayedSize()
        //{
        //    int pos = _secondaryBuffer.PlayPosition;
        //    return pos < _nextWritePos ? pos + _bufferByteCount - _nextWritePos : pos - _nextWritePos;
        //}

        private int GetWriteByteCount()
        {
            int playPos = _secondaryBuffer.PlayPosition;
            int endPos = _secondaryBuffer.PlayPosition + MsToBytes(_maxLatencyMs);
            int retVal = playPos > _nextWritePos && playPos > _bufferByteCount / 2 ?
                endPos - (_nextWritePos + _bufferByteCount) :
                endPos - _nextWritePos;

            if (retVal < 0 || retVal > _bufferByteCount)
            {
                Console.WriteLine("Too much!");
                return 0;
                //throw new Exception();
            }

            return retVal;
        }

        private void Timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            int w = _nextWritePos;

            Feed(GetWriteByteCount());

            int r = _secondaryBuffer.PlayPosition;
            //Console.WriteLine("write: " + w + "\tread: " + r + "\t diff (ms): " + BytesToMs(w - r));
        }
    }
}
