﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

namespace TabletSynth
{
    class CombSource
    {
        const double TWO_PI = 2 * Math.PI;
        Random _random = new Random();

        int _sampleRate;
        double[] _frequencies;
        double[] _phases;

        double _ampScale;
        double _ampThreshold;
        double _w0;
        double _combSharpness;
        double _lowpassCenter;
        double _lowpassExp;
        double _lowpassWidth;
        int _sinusoidCount;
        short[] _samples;
        bool _invertBandpass;
        bool _invertComb;

        short[] _sampleCache1;
        short[] _sampleCache2;

        const double B = 4.0 / Math.PI;
        const double C = -4.0 / (Math.PI * Math.PI);
        const double P = 0.225;

        public CombSource(int sampleRate, double minFrequency, double maxFrequency, int frequencySamples)
        {
            _ampScale = 0;
            _ampThreshold = 0.02;
            _w0 = 65.41;
            _combSharpness = 1000;
            _lowpassCenter = 1.6;
            _lowpassExp = 3.0;
            _lowpassWidth = 20.5;
            _sinusoidCount = 900;
            _samples = new short[0];
            FilterFunction1 = Comb1;
            FilterFunction2 = Bandpass2;

            _sampleRate = sampleRate;
            _frequencies = new double[frequencySamples];
            _phases = new double[frequencySamples];
            double fqRes = (maxFrequency - minFrequency) / frequencySamples;
            for (int i = 0; i < frequencySamples; i++)
            {
                _phases[i] = TWO_PI * _random.NextDouble();
                _frequencies[i] = TWO_PI * (minFrequency + i * fqRes);
            }

            _sampleCache1 = new short[2 * sampleRate];
            _sampleCache2 = new short[2 * sampleRate];
        }

        public double FundamentalFrequency
        {
            get { return _w0; }
            set { _w0 = value; }
        }

        public double CombSharpness
        {
            get { return _combSharpness; }
            set { _combSharpness = value; }
        }

        public double LowpassCenter
        {
            get { return _lowpassCenter; }
            set { _lowpassCenter = value; }
        }

        public double LowpassExponent
        {
            get { return _lowpassExp; }
            set { _lowpassExp = value; }
        }

        public double LowpassWidth
        {
            get { return _lowpassWidth; }
            set { _lowpassWidth = value; }
        }

        public double Amplitude
        {
            set { _ampScale = value; }
            get { return _ampScale; }
        }

        public int Sinusoids
        {
            get { return _sinusoidCount; }
            set { _sinusoidCount = value; }
        }

        public bool InvertBandpass
        {
            set { _invertBandpass = value; }
            get { return _invertBandpass; }
        }

        public bool InvertComb
        {
            set { _invertComb = value; }
            get { return _invertComb; }
        }

        public FilterFunction FilterFunction2 { get; set; }

        public FilterFunction FilterFunction1 { get; set; }

        public static double Comb1(double frequency, double w0, double center, double width, double sharpness, double exponent)
        {
            return 1 / (sharpness - (sharpness - 1) * Math.Cos(frequency / w0));
        }

        public static double Bandpass1(double frequency, double w0, double center, double width, double sharpness, double exponent)
        {
            return 1 / (1 + Math.Pow(Math.Abs((width * (frequency - TWO_PI * center * w0))), exponent));
        }

        public static double Bandpass2(double frequency, double w0, double center, double width, double sharpness, double exponent)
        {
            double f_1 = (frequency - TWO_PI * center * w0) * width - 1; //shift 1 to center around maximum
            double f_2 = f_1 * f_1;
            double f_3 = f_2 * f_1;
            double f_4 = f_2 * f_2;
            return 1.0 / Math.Pow(23.0 / 12.0 +
                f_4 * 0.25 - f_3 * 0.333333 - f_2 * 0.5 + f_1, exponent);
        }

        public void GetAmplitudeEnvelope(ref double[] envelope, ref double[] bandpass)
        {
            double w0 = _w0;
            double combSharpness = _combSharpness;
            double lowpassCenter = _lowpassCenter;
            double lowpassExp = _lowpassExp;
            double lowpassWidth = 1.0 / (w0 * _lowpassWidth);
            double ampScale = _ampScale;
            int sinusoidCount = _sinusoidCount;
            bool invertBandpass = _invertBandpass;
            bool invertComb = _invertComb;
            FilterFunction filter1 = FilterFunction1;
            FilterFunction filter2 = FilterFunction2;

            int fqCount = _frequencies.Length;
            double minFrequency = w0 / 2;
            double frequencyResolution = 15000 / envelope.Length;

            for (int i = envelope.Length - 1; i != -1; i--)
            {
                double frequency = TWO_PI * (minFrequency + i * frequencyResolution);

                double comb = filter1(frequency, w0, lowpassCenter, lowpassWidth, combSharpness, lowpassExp);

                if (invertComb)
                    comb = 1 - comb;

                //double lowpass = 1 / (1 + Math.Pow(Math.Abs(
                //    (lowpassWidth * (frequency - TWO_PI * lowpassCenter * w0))), lowpassExp));

                double lowpass = filter2(frequency, w0, lowpassCenter, lowpassWidth, combSharpness, lowpassExp);

                if (invertBandpass)
                    lowpass = 1 - lowpass;

                lowpass *= ampScale;
                bandpass[i] = lowpass;
                envelope[i] = comb * lowpass;
            }
        }

        public void GetSamples(IntPtr dataPtr, int byteCount)
        {
            long time = HiResTimer.Ticks;

            double w0 = _w0;
            double combSharpness = _combSharpness;
            double lowpassCenter = _lowpassCenter;
            double lowpassExp = _lowpassExp;
            double lowpassWidth = 1.0 / (w0 * _lowpassWidth);
            double ampScale = _ampScale;
            int sinusoidCount = _sinusoidCount;
            bool invertBandpass = _invertBandpass;
            bool invertComb = _invertComb;
            FilterFunction filter1 = FilterFunction1;
            FilterFunction filter2 = FilterFunction2;

            int sampleCount = byteCount / 2; //short = two bytes
            if (_samples.Length < sampleCount)
                _samples = new short[sampleCount];

            double[] amplitude = new double[_frequencies.Length];

            Random random = new Random();

            System.Threading.Collections.ConcurrentStack<int> importantFqIndices
                = new System.Threading.Collections.ConcurrentStack<int>();

            /*
             * Calculate amplitude of comb * lowpass.
             * Store index if amplitude is high enough.
             */
            int fqCount = _frequencies.Length;
            double minFrequency = w0 * 0.5;
            double frequencyResolution = w0 / 150.0;

            Parallel.For(0, fqCount, i =>
            //for (int i = 0; i < fqCount; i++)
            {
                double frequency = TWO_PI * (minFrequency + i * frequencyResolution);
                _frequencies[i] = frequency;

                if (frequency < TWO_PI * 20000)
                {
                    double comb = filter1(frequency, w0, lowpassCenter, lowpassWidth, combSharpness, lowpassExp);

                    if (invertComb)
                        comb = 1 - comb;

                    if (comb > _ampThreshold)//&& importantFqIndices.Count < sinusoidCount)
                    {
                        //double lowpass = 1 / (1 + Math.Pow(Math.Abs(
                        //    (lowpassWidth * (frequency - TWO_PI * lowpassCenter * w0))), lowpassExp));

                        double lowpass = filter2(frequency, w0, lowpassCenter, lowpassWidth, combSharpness, lowpassExp);

                        if (invertBandpass)
                            lowpass = 1 - lowpass;

                        double ampTmp = comb * lowpass;
                        if (ampTmp > _ampThreshold)
                        {
                            //ampTmp *= random.NextDouble();
                            amplitude[i] = ampTmp;
                            importantFqIndices.Push(i);
                        }
                    }
                }
            });
            //}


            long time2 = HiResTimer.Ticks;

            //Copy important frequencies and their amplitudes to arrays, for faster access below
            int[] importantFqIndicesArr = new int[importantFqIndices.Count];
            double[] amplitudeHigh = new double[importantFqIndices.Count];
            int asd = 0;
            foreach (int i in importantFqIndices)
            {
                importantFqIndicesArr[asd] = i;
                amplitudeHigh[asd] = amplitude[i];
                asd++;
            }
            Array.Sort(amplitudeHigh, importantFqIndicesArr);


            //Create output samples
            double one_over_sr = 1.0 / _sampleRate;
            int innerLoopEnd = Math.Max(importantFqIndicesArr.Length - sinusoidCount, -1);

            double sampleScale = 0;
            for (int j = importantFqIndicesArr.Length - 1; j != innerLoopEnd; j--)
                sampleScale += Math.Sqrt(amplitudeHigh[j]);
            sampleScale = ampScale * short.MaxValue / sampleScale;

            //for (int t = 0; t < sampleCount; t++)
            Parallel.For(0, sampleCount, t =>
            {
                double soundSample = 0;

                //For every frequency component with high enough amplitude
                double t_samplerate = t * one_over_sr;
                for (int j = importantFqIndicesArr.Length - 1; j != innerLoopEnd; j--)
                {
                    int i = importantFqIndicesArr[j];
                    //Calculate the new phase for this frequency and timestep
                    double phase = _phases[i] + _frequencies[i] * t_samplerate;

                    soundSample += amplitudeHigh[j] * Math.Sin(phase);
                }

                soundSample *= sampleScale;
                //if (Math.Abs(soundSample) > short.MaxValue)
                //    Console.WriteLine("Overflow!");
                //Clamp to 16 bit range [-32767, 32767]
                _samples[t] = (short)(soundSample > short.MaxValue ?
                    short.MaxValue :
                    (soundSample < short.MinValue ? short.MinValue : soundSample));
            });
            //}

            long time3 = HiResTimer.Ticks;

            //Add reverb
            //Copy cached data into buffer
            Array.Copy(_sampleCache2, sampleCount, _sampleCache1, 0, _sampleCache1.Length - sampleCount);
            //Copy samples into buffer
            Array.Copy(_samples, 0, _sampleCache1, _sampleCache1.Length - sampleCount, sampleCount);
            //Filter
            for (int i = _sampleCache1.Length - sampleCount; i < _sampleCache1.Length; i++)
            {
                _sampleCache1[i] = (short)(
                    _sampleCache1[i] * 1 +
                    _sampleCache1[i - 1123] * 0.57 +
                    _sampleCache1[i - 10000] * 0.1 +
                    _sampleCache1[i - 25000] * 0.03);
            }
            //Swap buffers
            Array.Copy(_sampleCache1, _sampleCache2, _sampleCache2.Length);

            //Update phase of all frequencies to end of sample series
            for (int i = 0; i < _phases.Length; i++)
            {
                _phases[i] = (_phases[i] + _frequencies[i] * sampleCount / _sampleRate) % TWO_PI;
            }

            System.Runtime.InteropServices.Marshal.Copy(_sampleCache1, _sampleCache1.Length - sampleCount, dataPtr, sampleCount);

            //Console.WriteLine(sampleCount);
            //double tScale = 1000.0 / HiResTimer.TicksPerSecond;
            //Console.WriteLine(importantFqIndices.Count + " T1:\t" + (time2 - time) * tScale + "T2:\t" + (time3 - time2) * tScale + "T3:\t" + (HiResTimer.Ticks - time3) * tScale);
            //Console.WriteLine(1000 * (HiResTimer.Ticks - time) / (double)HiResTimer.TicksPerSecond);
        }
    }
}
