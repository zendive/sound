﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TabletSynth
{
    public interface IParameterMapper
    {
        double GetMappedValue(double pressure1, double x1, double y1, double s1, double t1, double pressure2, double x2, double y2, double s2, double t2, double sinusoidCount, double noteCount, double minFq, bool discreteNotes);
    }
}
