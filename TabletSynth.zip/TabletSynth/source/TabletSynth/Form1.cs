﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using Microsoft.DirectX.DirectSound;
using Microsoft.DirectX.Direct3D;
using Microsoft.DirectX;
using VBTablet;
using Microsoft.CSharp;
using System.CodeDom.Compiler;
using System.Reflection;

namespace TabletSynth
{
    public delegate double ParameterMapping(double pressure1, double x1, double y1, double s1, double t1, double pressure2, double x2, double y2, double s2, double t2, double sinusoidCount, double noteCount, double minFq, bool discreteNotes);

    public delegate double FilterFunction(double frequency, double w0, double center, double width, double sharpness, double exponent);

    public partial class TabletSynth : Form
    {

        StreamingPlayer _player;
        long _startTime = HiResTimer.Ticks;
        CombSource _source;
        Tablet _tablet;
        Microsoft.DirectX.Direct3D.Device _d3dDevice;
        CustomVertex.PositionOnly[] _envelopeVertices;
        System.Windows.Forms.Timer _renderTimer;

        double[] _frequencyEnvelope;
        double[] _frequencyEnvelopeBandpass;

        double _pressure1, _pressure2, _x1, _x2, _y1, _y2, _s1, _s2, _t1, _t2;

        ParameterMapping GetW0;
        ParameterMapping GetAmplitude;
        ParameterMapping GetWidth;
        ParameterMapping GetCenter;
        ParameterMapping GetExponent;
        ParameterMapping GetSharpness;

        public TabletSynth()
        {
            InitializeComponent();

            _player = new StreamingPlayer(this, StreamingPlayer.CreateWaveFormat(44100, 16, 1));

            try
            {
                _tablet = new Tablet();
                _tablet.hWnd = this.Handle;
                _tablet.Connected = true;
                _tablet.Context.Enabled = true;
                _tablet.Context.Options.IsSystemCtx = false;
                _tablet.Context.Update();
                _tablet.Context.QueueSize = 32;
                _tablet.PacketArrival += new Tablet.PacketArrivalEventHandler(_tablet_PacketArrival);
            }
            catch (Exception)
            {
                MessageBox.Show("No tablet connected. Parts of the application will not function properly.");
            }

            _frequencyEnvelope = new double[panelGraph.Width];
            _frequencyEnvelopeBandpass = new double[panelGraph.Width];

            CreateD3DDevice();

            ParseParameterMappingCode(textBoxW0Code, ref GetW0);
            ParseParameterMappingCode(textBoxAmplitudeCode, ref GetAmplitude);
            ParseParameterMappingCode(textBoxWidthCode, ref GetWidth);
            ParseParameterMappingCode(textBoxCenterCode, ref GetCenter);
            ParseParameterMappingCode(textBoxSharpnessCode, ref GetSharpness);
            ParseParameterMappingCode(textBoxExponentCode, ref GetExponent);

            /*
             * Initialize player
             */
            _source = new CombSource(44100, 20, 10000, 5000);
            textBoxSinusoidCount.Text = _source.Sinusoids.ToString();
            _player.Play(_source.GetSamples);

            if (_renderTimer == null)
                _renderTimer = new System.Windows.Forms.Timer();

            _renderTimer.Interval = 1000 / 30;
            _renderTimer.Tick += new EventHandler(UpdateGraph);
            _renderTimer.Start();
        }

        void CreateD3DDevice()
        {
            PresentParameters p = new PresentParameters();
            p.SwapEffect = SwapEffect.Discard;
            p.Windowed = true;

            _d3dDevice = new Microsoft.DirectX.Direct3D.Device(0, DeviceType.Hardware, panelGraph, CreateFlags.HardwareVertexProcessing, p);
            _d3dDevice.RenderState.CullMode = Cull.None;
            _d3dDevice.RenderState.Lighting = true;
            _d3dDevice.DeviceReset += new EventHandler(_d3dDevice_DeviceReset);

            _envelopeVertices = new CustomVertex.PositionOnly[panelGraph.Width];

            Random r = new Random();
            for (int i = 0; i < _envelopeVertices.Length; i++)
            {
                _envelopeVertices[i] = new CustomVertex.PositionOnly(
                    2 * i / (float)_envelopeVertices.Length - 1, 
                    1f/panelGraph.Height - 1, 
                    0);
            }
        }

        void _d3dDevice_DeviceReset(object sender, EventArgs e)
        {
            
        }

        double Clamp(double x, double min, double max)
        {
            double a = x > min ? x : min;
            return a < max ? a : max;
        }

        void _tablet_PacketArrival(
            ref IntPtr ContextHandle, 
            ref int Cursor, 
            ref int X, 
            ref int Y, 
            ref int Z, 
            ref int Buttons, 
            ref int NormalPressure, 
            ref int TangentPressure, 
            ref int Azimuth, 
            ref int Altitude, 
            ref int Twist, 
            ref int Pitch, 
            ref int Roll, 
            ref int Yaw, 
            ref int PacketSerial, 
            ref int PacketTime)
        {
            double phi = 0.5 * Math.PI * (900 - Altitude) / 700.0;
            double r = Math.Sin(phi);
            double alpha = 2 * Math.PI * Azimuth / 3600.0;
            double beta = Math.Abs((alpha + Math.PI / 4) % (Math.PI / 2) - Math.PI / 4) * 4 / Math.PI;
            double rs = Math.Sqrt(1 + Math.Sin(beta) * Math.Sin(beta));
            rs = Math.Pow(rs, 1.05); //Fix the pen's Altitude dependent Azimuth variation. Not perfect.
            double s = -Clamp(rs * r * Math.Sin(alpha), -1, 1);
            double t = Clamp(rs * r * Math.Cos(alpha), -1, 1);
            double x = X / (double)SystemInformation.PrimaryMonitorSize.Width;
            double y = Y / (double)SystemInformation.PrimaryMonitorSize.Height;
            double sinusoidCount = double.Parse(textBoxSinusoidCount.Text);
            double minFq = double.Parse(textBoxMinFq.Text);
            double noteCount = double.Parse(textBoxNoteCount.Text);

            label7.Text =
                "X:               " + X + "\n" +
                "Y:               " + Y + "\n" +
                "Z:               " + Z + "\n" +
                "NormalPressure:  " + NormalPressure + "\n" +
                "TangentPressure: " + TangentPressure + "\n" +
                "Azimuth:         " + Azimuth + "\n" +
                "Altitude:        " + Altitude + "\n" +
                "Twist:           " + Twist + "\n" +
                "Pitch:           " + Pitch + "\n" +
                "Roll:            " + Roll + "\n" +
                "Yaw:             " + Yaw;

            if (Cursor == int.Parse(textBoxPen1.Text))
            {
                _pressure1 = NormalPressure;
                _x1 = x;
                _y1 = y;
                _s1 = s;
                _t1 = t;

                _source.InvertBandpass = (Buttons == 3 || Buttons == 7);

                _source.InvertComb = (Buttons == 5 || Buttons == 7);

            }
            else if (Cursor == int.Parse(textBoxPen2.Text))
            {
                _pressure2 = NormalPressure;
                _x2 = x;
                _y2 = y;
                _s2 = s;
                _t2 = t;

                if (Buttons == 1)
                    _source.FilterFunction2 = CombSource.Bandpass2;
                else if (Buttons == 4)
                    _source.FilterFunction2 = CombSource.Bandpass1;
            }

            labelTabletData.Text =
                "Cursor:    " + Cursor + "\n" +
                "Buttons:   " + Buttons + "\n" +
                "x1:        " + _x1 + "\n" +
                "y1:        " + _y1 + "\n" +
                "s1:        " + _s1 + "\n" +
                "t1:        " + _t1 + "\n" +
                "pressure1: " + _pressure1 + "\n" +
                "x2:        " + _x2 + "\n" +
                "y2:        " + _y2 + "\n" +
                "s2:        " + _s2 + "\n" +
                "t2:        " + _t2 + "\n" +
                "pressure2: " + _pressure2;

            _source.Amplitude = GetAmplitude(_pressure1, _x1, _y1, _s1, _t1, _pressure2, _x2, _y2, _s2, _t2, sinusoidCount, noteCount, minFq, radioButtonDiscrete.Checked);
            _source.FundamentalFrequency = GetW0(_pressure1, _x1, _y1, _s1, _t1, _pressure2, _x2, _y2, _s2, _t2, sinusoidCount, noteCount, minFq, radioButtonDiscrete.Checked);
            _source.CombSharpness = GetSharpness(_pressure1, _x1, _y1, _s1, _t1, _pressure2, _x2, _y2, _s2, _t2, sinusoidCount, noteCount, minFq, radioButtonDiscrete.Checked);
            _source.LowpassCenter = GetCenter(_pressure1, _x1, _y1, _s1, _t1, _pressure2, _x2, _y2, _s2, _t2, sinusoidCount, noteCount, minFq, radioButtonDiscrete.Checked);
            _source.LowpassWidth = GetWidth(_pressure1, _x1, _y1, _s1, _t1, _pressure2, _x2, _y2, _s2, _t2, sinusoidCount, noteCount, minFq, radioButtonDiscrete.Checked);
            _source.LowpassExponent = GetExponent(_pressure1, _x1, _y1, _s1, _t1, _pressure2, _x2, _y2, _s2, _t2, sinusoidCount, noteCount, minFq, radioButtonDiscrete.Checked);
        }

        void UpdateGraph(object sender, EventArgs e)
        {
            if (_source != null)
            {
                _d3dDevice.Clear(ClearFlags.Target, Color.Black, 1.0f, 0);
                _d3dDevice.BeginScene();
                _d3dDevice.VertexFormat = CustomVertex.PositionOnly.Format;

                Material m = new Material();

                _source.GetAmplitudeEnvelope(ref _frequencyEnvelope, ref _frequencyEnvelopeBandpass);

                for (int i = _frequencyEnvelope.Length - 1; i != -1; i--)
                    _envelopeVertices[i].Y = 2 * (float)_frequencyEnvelopeBandpass[i] - 1;

                m.Diffuse = m.Emissive = Color.Gray;
                _d3dDevice.Material = m;
                _d3dDevice.DrawUserPrimitives(PrimitiveType.LineStrip, _envelopeVertices.Length - 1, _envelopeVertices);

                for (int i = _frequencyEnvelope.Length - 1; i != -1; i--)
                    _envelopeVertices[i].Y = 2 * (float)_frequencyEnvelope[i] - 1;

                m.Diffuse = m.Emissive = Color.White;
                _d3dDevice.Material = m;
                _d3dDevice.DrawUserPrimitives(PrimitiveType.LineStrip, _envelopeVertices.Length - 1, _envelopeVertices);

                _d3dDevice.EndScene();
                _d3dDevice.Present();
            }
        }

        void textBox1_TextChanged(object sender, EventArgs e)
        {
            try
            {
                _source.Sinusoids = int.Parse(textBoxSinusoidCount.Text);
            }
            catch
            {

            }
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            _player.Stop();
            if (_d3dDevice != null)
                _d3dDevice.Dispose();
            base.OnClosing(e);
        }

        /// <summary>
        /// Attempts to compile a new IParameterMapper object from a source function. The
        /// function string must be valid C# code for it to work.
        /// </summary>
        /// <param name="source">The source code of the function to compile.</param>
        /// <returns></returns>
        IParameterMapper CompileMapper(string source)
        {
            string classSource =
                "using System;" +
                "using System.Collections.Generic;" +
                "using System.ComponentModel;" +
                "using System.Drawing;" +
                "using System.Text;" +
                "using System.Windows.Forms;" +
                "namespace TabletSynth" +
                "{" +
                "public class Mapper : IParameterMapper" +
                "{" +
                "public double GetMappedValue(double pressure1, double x1, double y1, double s1, double t1, double pressure2, double x2, double y2, double s2, double t2, double sinusoidCount, double noteCount, double minFq, bool discreteNotes)" +
                "{" + source + "}" +
                "}}";
            
            CSharpCodeProvider codeProvider = new CSharpCodeProvider();
            CompilerParameters compilerParams = new CompilerParameters();
            compilerParams.GenerateInMemory = true;
            compilerParams.IncludeDebugInformation = true;
            compilerParams.ReferencedAssemblies.Add("System.Windows.Forms.dll");
            compilerParams.ReferencedAssemblies.Add(Assembly.GetAssembly(typeof(IParameterMapper)).Location);
            CompilerResults result = codeProvider.CompileAssemblyFromSource(compilerParams, new string[] { classSource });

            if (result.Errors.Count == 0)
            {
                return (IParameterMapper)result.CompiledAssembly.CreateInstance("TabletSynth.Mapper");
            }
            else
                return null;
        }

        /// <summary>
        /// Attempts to compile a new IFrequencyFilter object from a source function. The
        /// function string must be valid C# code for it to work.
        /// </summary>
        /// <param name="source">The source code of the function to compile.</param>
        /// <returns></returns>
        IFrequencyFilter CompileFilter(string source)
        {
            string classSource =
                "using System;" +
                "using System.Collections.Generic;" +
                "using System.ComponentModel;" +
                "using System.Drawing;" +
                "using System.Text;" +
                "using System.Windows.Forms;" +
                "namespace TabletSynth" +
                "{" +
                "public class Filter : IFrequencyFilter" +
                "{" +
                "public double GetAmplitude(double frequency, double w0, double center, double width, double sharpness, double exponent)" +
                "{" + source + "}" +
                "}}";

            CSharpCodeProvider codeProvider = new CSharpCodeProvider();
            CompilerParameters compilerParams = new CompilerParameters();
            compilerParams.GenerateInMemory = true;
            compilerParams.IncludeDebugInformation = true;
            compilerParams.ReferencedAssemblies.Add("System.Windows.Forms.dll");
            compilerParams.ReferencedAssemblies.Add(Assembly.GetAssembly(typeof(IParameterMapper)).Location);
            CompilerResults result = codeProvider.CompileAssemblyFromSource(compilerParams, new string[] { classSource });

            if (result.Errors.Count == 0)
            {
                return (IFrequencyFilter)result.CompiledAssembly.CreateInstance("TabletSynth.Filter");
            }
            else
                return null;
        }

        void ParseParameterMappingCode(TextBox textbox, ref ParameterMapping function)
        {
            IParameterMapper mapper = CompileMapper(textbox.Text);
            if (mapper != null)
            {
                function = mapper.GetMappedValue;
                textbox.ForeColor = Color.Black;
            }
            else
                textbox.ForeColor = Color.Red;
        }

        private void textBoxW0Code_TextChanged(object sender, EventArgs e)
        {
            ParseParameterMappingCode((TextBox)sender, ref GetW0);
        }

        private void textBoxAmplitudeCode_TextChanged(object sender, EventArgs e)
        {
            ParseParameterMappingCode((TextBox)sender, ref GetAmplitude);
        }

        private void textBoxWidthCode_TextChanged(object sender, EventArgs e)
        {
            ParseParameterMappingCode((TextBox)sender, ref GetWidth);
        }

        private void textBoxCenterCode_TextChanged(object sender, EventArgs e)
        {
            ParseParameterMappingCode((TextBox)sender, ref GetCenter);
        }

        private void textBoxSharpnessCode_TextChanged(object sender, EventArgs e)
        {
            ParseParameterMappingCode((TextBox)sender, ref GetSharpness);
        }

        private void textBoxExponentCode_TextChanged(object sender, EventArgs e)
        {
            ParseParameterMappingCode((TextBox)sender, ref GetExponent);
        }

        private void textBoxFunction1_TextChanged(object sender, EventArgs e)
        {
            IFrequencyFilter filter = CompileFilter(textBoxFunction1.Text);
            if (filter != null)
            {
                _source.FilterFunction1 = filter.GetAmplitude;
                textBoxFunction1.ForeColor = Color.Black;
            }
            else
                textBoxFunction1.ForeColor = Color.Red;

        }

        private void textBoxFunction2_TextChanged(object sender, EventArgs e)
        {
            IFrequencyFilter filter = CompileFilter(textBoxFunction2.Text);
            if (filter != null)
            {
                _source.FilterFunction2 = filter.GetAmplitude;
                textBoxFunction2.ForeColor = Color.Black;
            }
            else
                textBoxFunction2.ForeColor = Color.Red;
        }
    }
}
