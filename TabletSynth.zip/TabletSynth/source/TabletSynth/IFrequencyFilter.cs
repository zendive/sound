﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TabletSynth
{
    public interface IFrequencyFilter
    {
        double GetAmplitude(double frequency, double w0, double center, double width, double sharpness, double exponent);
    }
}
